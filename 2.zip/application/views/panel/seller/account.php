<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php foreach ($this->user_model->view_token() as $row): ?>
	<?php
$line_api = 'https://notify-api.line.me/api/notify';
$access_token = $row['add_vpn'];
?>
<?php endforeach; ?>



<?php
$host=getenv('HTTP_HOST');

$datecr= date("d-m-Y");

$dateexp= date("d-m-Y",strtotime("+".$user['expired']." days", time() ) );





$str =' 
**********************
 🌍  http://'.$host.'
 🤵  สมาชิก     : '.$_SESSION['username'].' 
 🌐  เซิฟร์เวอร์ : '.$server->Location.' 
 🚹  ยุสเซอร์    : '.$user['username'].'    
 🔑  รหัสผ่าน   : '.$user['password'].' 
 💳  ราคา         : '.$user['price'].' บาท 
 📌  วันใช้งาน  : '.$user['expired'].' วัน 
 📆  วันที่สร้าง  : '.$datecr.'
  📊 ใช้ได้ถึ่ง    : '.$dateexp;
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">
                บันชี VPN
            </h3>
        </div>
    </div>
    <div class="row">
            
               <center> <?= $user['message']?></center><br>
                 
					    <div class="col-lg-12">
        <div class="center">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <i class="fa fa-user fa-fw"></i> สร้างบันชีสำเร็จ
                </div>
                <div class="panel-body">
                <table class="table table-hover">
                    <tbody>
                        
                            <tr>
                            <td><font color="#0012FF">เซิฟร์เวอร์</td><td>:</td><td><font color="#0046FF"><?= $server->Location ?></td>
                        </tr>
                        <tr>
                            <td><font color="#0012FF">ชื่อผู้ใช้</td><td>:</td><td><font color="#0012FF"><?= $user['username']?></td>
                        </tr>
                        <tr>
                            <td><font color="#00A3FF">รหัสผ่าน</td><td>:</td><td><font color="#00A3FF"><?= $user['password']?></td>
                        </tr>
                              <tr>
                            <td><font color="#0032FF">ราคา</td><td>:</td><td><font color="#0032FF"><?= $user['price']?> บาท</td>
                        </tr>
                          
                        
                        <tr>
                            <td><font color="#FF003C">ใช้ได้ถึ่ง</td><td>:</td><td><font color="#FF0021"><?= date("d-m-Y ",strtotime("+".$user['expired']." days", time() ) )?>00.00น.</td>
                        </tr>
                        
                    </tbody>
                </table>
                
                <div class="hidden-print">
				    <a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/download') ?>" class="btn btn-danger"><i class="fa fa-download fa-fw"></i> ovpn</a>
						
					<a href="<?= base_url('panel/reseller/'.$_SESSION['username'].'/server') ?>" class="btn btn-warning">ย้อนกลับ</a>
					
					</div>
				</div>
            </div>
        </div>
    </div>
</div>

<font color="ffffff">
<?php
$image_thumbnail_url = '';  // ขนาดสูงสุด 240?240px JPEG
$image_fullsize_url = '';  // ขนาดสูงสุด 1024?1024px JPEG
$sticker_package_id = '';  // Package ID ของสติกเกอร์
$sticker_id = '';    // ID ของสติกเกอร์

$message_data = array(
 'message' => $str,
 'imageThumbnail' => $image_thumbnail_url,
 'imageFullsize' => $image_fullsize_url,
 'stickerPackageId' => $sticker_package_id,
 'stickerId' => $sticker_id
);

$result = send_notify_message($line_api, $access_token, $message_data);
print_r($result);

function send_notify_message($line_api, $access_token, $message_data)
{
 $headers = array('Method: POST', 'Content-type: multipart/form-data', 'Authorization: Bearer '.$access_token );

 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $line_api);
 curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $result = curl_exec($ch);
 // Check Error
 if(curl_error($ch))
 {
  $return_array = array( 'status' => '000: send fail', 'message' => curl_error($ch) ); 
 }
 else
 {
  $return_array = json_decode($result, true);
 }
 curl_close($ch);
 
}

?>
</font>
