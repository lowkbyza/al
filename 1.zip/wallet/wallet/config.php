<?php
$host = 'localhost';
$user = 'root'; //user database
$pass = 'lowkby'; //pass database
$db = 'lowkby'; //database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con,'utf8');