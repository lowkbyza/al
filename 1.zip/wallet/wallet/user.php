﻿<?php
SESSION_START();
include 'config.php';
if(!$_SESSION['user']['username']){
	header("location: login.php");
}

?>

<html>
<head>
<title> Wallet Topup</title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-sm-6 col-md-4 col-lg-3">
<form action="wallet.php" method="post">
	<div class="form-group">
		<p><h4><b>นำ "เลขที่อ้างอิง" มาใส่ในช่องด้านล่าง</b></h4></p>
		<input type="text" class="form-control" maxlength="20" name="wallet" placeholder="ใส่เลขที่อ้างอิง">
	</div>
<p>* ตัวอย่าง เช่น 50000999999999 (จำนวน 14 ตัว)</p>
<input type="submit" class="btn btn-success" value="เติมพ้อย">  <a href="http://vpn.tsp-network.net/wallet" class="btn btn-default">ย้อนกลับ</a>
</form>
</div>
<?php
$sql = "select * from users where username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>

<p><b>&nbsp;&nbsp;&nbsp ชื่อผู้ใช้งาน : </b><?php echo $result['username'];?></p>
<p><b>&nbsp;&nbsp;&nbsp พ้อยคงเหลือ : </b><?php echo $result['saldo'];?> พ้อย <font color="red">👇รูปภาพตัวอย่าง เลขที่อ้างอิง</font></p>&nbsp;&nbsp;&nbsp;
<img src="/images/truecode.jpeg" width="330" height="330"/>
</div>
</div>
</body>
</html>