﻿<html>
<head>
<title>Login</title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
<div class="container">
<div class="row">
<div class="col-sm-6 col-md-4 col-lg-3">
<form action="check.php" method="post">
	<div class="form-group">
		<h3>ชื่อผู้ใช้งาน (ที่ใช้เข้าสู่ระบบเว็บ)</h3>
		<input type="text" class="form-control" name="user" placeholder="ใส่ชื่อผู้ใช้งาน">
	</div>
<p> * เติมผ่าน แอพทรูวอเลท<br> &nbsp;&nbsp; โอนมาที่ เบอร์ 0958438433 (พรรณี งิ้วทอง)</p>
<p> * เติมผ่าน เซเว่น<br> &nbsp;&nbsp; แจ้งพนักงานเซเว่น เบอร์ 0958438433 (พรรณี งิ้วทอง)</p>
		<input type="submit" class="btn btn-success" value="เข้าสู่ระบบเช็คเลขที่อ้างอิง"> <a href="http://vpn.tsp-network.net" class="btn btn-default">ย้อนกลับ</a>
</form>
</div>
</div>
<p>* วิธีเติมพ้อย<br>เพียงแค่นำ เลขที่อ้างอิง ในแอพทรูวอเลท มาใส่<br>หรือนำ เลขในบิลที่เติมทรูวอเลทจากเซเว่น มาใส่</p>
<p>* กฎการเติมพ้อย
<br>แอพทรูวอเลทเติมจำนวนเต็มสิบ 10-100,300,500,1000<br>ถ้าไม่ใช่จำนวนตามนี้พ้อยจะไม่เข้าระบบ</p>
<p>เติมที่เซเว่น ราคาที่เติม 100 = 100 พ้อย</p>
</div>
</body>
</html>