<?php
SESSION_START();
include 'wallet/config.php';
if(!$_SESSION['user']['username']){
header("location: login.php");
}

$sql = "SELECT * FROM users WHERE username='".$_SESSION['user']['username']."'";
$query = mysqli_query($con,$sql) or die ("Error Query");
$result = mysqli_fetch_assoc($query);

?>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>TRUE WALLET</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
			<div class="container">
					<div class="row">
						<div class="col-sm-6 col-md-4 col-lg-3">							
							 <form action="confirm.php" method="post">
									<div class="form-group">
											<h2>ชื่อบัญชี USERNAME</h2>
													<input class="form-control" placeholder="ใส่เลขอ้างอิง" name="wallet" type="number" required>
											</div>
													<input type="submit" class="btn btn-info form-control" value="ยืนยัน" name="wallet">
											</form>
											<div><a href="http://tmwallet.thaighost.net/images/transactionid.jpg" target="_transactionid">ตัวอย่าง การดูเลขอ้างอิง?</a></div></font>

	<p><b>ชื่อบัญชี :</b>			<?php echo $result['username'];?></p>
		<p><b>ยอนเงินคงเหลือ :</b>	    <?php echo $result['saldo'];?></p>
								</div> 							
						</div>
				</div>
		<body>
</html>