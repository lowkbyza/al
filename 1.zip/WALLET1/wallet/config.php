<?php
$host = 'localhost';
$user = 'root';
$pass = 'lowkby'; //ใส่รหัส mysql
$db = 'lowkby'; //ชื่อ database
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con);


$walletmoney = $_POST['wallet'];

ini_set('display_errors', 1);
include_once('manager/TrueWallet.php');
$wallet = new TrueWallet();

//ใส่ชื่อรหัส wallet ของคุณ
$username = "rklowkbyza@gmail.com";
$password = "031329604z";

$wallet->logout();
