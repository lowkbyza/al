<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>TRUE WALLET</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
			<div class="container">
					<div class="row">
						<div class="col-sm-6 col-md-4 col-lg-3">
							<form action="input.php" method="post">
									<div class="form-group">
											<h2>ชื่อบัญชี USERNAME</h2>
													<input type="text" class="form-control" name="user">
											</div>
													<input type="submit" class="btn btn-md btn-warning form-control" value="LOGIN">
											</form>
								</div> 							
						</div>
				</div>
		<body>
</html>