<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="container">
	<div class="row">
		<div class="col-lg-10">
			<div class="panel panel-primary">
				<div class="panel-heading"></div>
				<div class="panel-body">
				<?php if (validation_errors()) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?= validation_errors() ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if (isset($error)) : ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?= $error ?>
				</div>
			</div>
		<?php endif; ?>
			<center><b>
		<div class="col-md-12">
			<div class="page-header">
				<h3>สมัครเข้าใช้งาน</h3></b>
				</center>
			</div>
			<?= form_open() ?> 
				<center>
				<div class="form-group">
					<label for="username"><center>ชื่อผู้ใช้</label></center>
					<input type="text" class="form-control" id="username" name="username" placeholder="ชื่อผู้ใช้">
					<p class="help-block">มีตัวอักษรหรือตัวเลขอย่างน้อย 4 ตัว</p>
				</div>
				<div class="form-group">
					<label for="email"><center>อีเมล์</label></center>
					<input type="email" class="form-control" id="email" name="email" placeholder="อีเมล์">
					<p class="help-block">ที่อยู่อีเมล์ที่ถูกต้อง</p>
				</div>
				<div class="form-group">
					<label for="password"><center>รหัสผ่าน</label></center>
					<input type="password" class="form-control" id="password" name="password" placeholder="รหัสผ่าน">
					<p class="help-block">อย่างน้อย 6 ตัวอักษร</p>
				</div>
				<div class="form-group">
					<label for="password_confirm"><center>ยืนยันรหัสผ่าน</label></center>
					<input type="password" class="form-control" id="password_confirm" name="password_confirm" placeholder="ยืนยันรหัสผ่าน">
					<p class="help-block">ต้องตรงกับรหัสผ่านด้านบน</p>
				</div>
					<div class="form-group">
						<div class="input-group">
					 <input type="submit" class="btn btn-primary" value="สร้างบัญชี">
				</div>
			</form>
		</div>
				</div>
				<div class="panel-footer"></div>
			</div>
		</div>
	</div><!-- .row -->
</div><!-- .container -->
