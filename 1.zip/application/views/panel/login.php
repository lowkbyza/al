
<center>
<a href="https://images.cooltext.com/5071667.png"><img src="https://images.cooltext.com/5070661.png" width="364" height="37" alt="VPN INTERNET HIGHSPEED" /></a>
<br />
<a href="https://images.cooltext.com/5071667.png"><img src="https://images.cooltext.com/5070664.png" width="250" height="55" alt="ยินดีต้อนรับ" /></a>
<br />

<style type="text/css">
body {
background-image: url('http://207.148.77.146:81/App/Grey-Texture-Wallpaper-Free-1024x640.jpg');
background-repeat: no-repeat;
background-position: center center;
background-attachment: fixed;
-o-background-size: 100% 100%, auto;
-moz-background-size: 100% 100%, auto;
-webkit-background-size: 100% 100%, auto;
background-size: 100% 100%, auto;
}
</style>
</center>
  <body>
	  <section id="#login">
    <div class="container">
	  	<?php if (validation_errors()) : ?>
                    <div class="alert alert-danger"><?= validation_errors() ?></div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert"><?= $error ?></div>
					</div>
				<?php endif; ?>
				  <div class="panel-body text-center">
                        <?= form_open() ?>
                            <fieldset>
                                <div class="form-group">                  				<div class="row">
                    <div class="col-md-12 text-center">
                <div class="row">
                   
            <br>
<h3 class="box-title"><b> <marquee behavior="alternate"><marquee width="180">
<font color="#CCFF99">เนื่องจากเราแก้ราคาให้เติมเงินใด้ทุกราคา ถ้าเข้าด้วยชื่อเดิมไม่ใด้ขอให้ท่านสมัครสมาชิกใหม่ครับ!!!ติดปัญหาสมัครไม่ใด้ หรือ
ต้องการเปิดเว็บเช่า
กดติดต่อสอบถาม
ขอบคุณทุกท่านที่เข้ามาอุดหนุนเซิร์ฟเวอร์ของเรา</font></h3><br></marquee></marquee>
                     <h1 class="panel-title"><font color="#00FFFF"><b><I>ลงชื่อเข้าใช้</I></b></font>
                         </div>
                  
                 <div class="panel-body">
                        <form action="./login" method="post" accept-charset="utf-8">
                            <fieldset>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user-secret fa-fw"></i></span>
                                        <input class="form-control" placeholder="ชื่อผู้ใช้งาน {  ผู้ที่สมัครสมาชิกแล้ว }" name="username" type="text" autofocus required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock fa-fw"></i></span>
                                        <input class="form-control" placeholder="รหัสผ่าน" name="password" type="password" required>
                                     </div>                             
                                 </div>
                       <button class="btn btn-success btn-block" type="submit" name="submit"><i class="fa fa-ravelry" aria-hidden="true"></i> เข้าสู่ระบบ   VPN INTERNET HIGHSPEED
</button> 
                   <a href="<?= base_url('panel/register') ?>"
                        <button class="btn btn-warning btn-block"
                                <i class="fa fa-ravelry"></i> สมัครสมาชิก VPN INTERNET HIGHSPEED
</a>
<a href="https://images.cooltext.com/5071667.png"><img src="https://images.cooltext.com/5071220.png" width="350" height="140" alt="KGUZA  r " /></a>

                                </form>
                               </div>
                            </div>
<marquee>
<font color="#00FFFF"> กรุณาทำความเข้าใจเซิร์ฟเวอร์ เว็บz.com ถ้ามีการใช้งานเกิน10 GB/ชัวโมง ทางเว็บจะมีการลดความเร็วและจะกลับเป็นปกติใน24ชั่วโมง »»ความเร็วจะอยู่ตามพื้นที่ใช้งานและโทรศัพท์ของคุณ  เพื่อรักษาความเร็วให้คงอยู่ตลอดกรุณา </font><font color="red"> { อย่าเทสสปีด }</font><font color="#00FFFF">ข้อความนี้ถือว่าท่านใด้ตกลงยอมรับเงื่อนไขแล้วทางเราจะไม่มีการคืนเงินหรือรับผิดชอบเรื่องความเร็วใดๆทั้งสิ้น!!ทั้งนี้เราก็จะหาเซิร์ฟเวอร์ที่เร็วที่สุดเท่าที่หาใด้มาให้บริการ!!</font></h3><br></marquee>
<p>

   <center>
 <font color="#CCFF99">ติดต่อสอบถาม </font><a href="http://line.me/ti/p/Dh6o2a5Ar9">คลิกที่นี่</h4></a></div><br>

          <font color="#CCFF99">โหลดแอพโม openvpn</font><a href="http://207.148.77.146:81/App/Openvpn.apk">คลิกที่นี่</a></div></center>
</section>
  </body>
</html>

