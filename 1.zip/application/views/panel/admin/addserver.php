<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h3 class="page-header">
               เพิ่มเซิร์ฟเวอร์
            </h3>
        </div>
    </div>
    <div class="row">
            <div class="col-lg-12">
				<?php if (isset($message)) { echo $message; }?>               
            </div>
        <div class="col-sm-6 col-md-4 col-lg-3">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                    <i class="fa fa-gear fa-fw"></i> ตั้งค่าเซิร์ฟเวอร์
                </div>
                <div class="panel-body">
                    <form action="<?= base_url('panel/administrator/'.$_SESSION['username'].'/'.'addserver') ?>" method="POST">
                        <div class="form-group">
                            <label>ตั้งชื่อ</label>
                            <input class="form-control" placeholder="ชื่อเซิร์ฟเวอร์" name="ServerName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ที่ตั้งเซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="ประเทศ" name="Location" type="text" required>     
                        </div>
                        <div class="form-group">
                            <label>โฮส ไอพี</label>
                            <input class="form-control" placeholder="ใส่โฮส หรือ ไอพี" name="HostName" type="text" required>
                        </div>
                        <div class="form-group">
                            <label>ราคาที่เปิดเช่า</label>
                            <div class="input-group">
                                <span class="input-group-addon">บาท</span>
                                <input class="form-control" placeholder="ใส่จำนวนเต็มสิบ" name="Price" type="number" step="01" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>รหัสผ่านเซิร์ฟเวอร์</label>
                            <input class="form-control" placeholder="ใส่รหัสรูทจากเซิฟที่เช่า" name="RootPasswd" type="text">
                        </div>
                        <input type="submit" class="btn btn-primary" value="เพิ่มเซิร์ฟเวอร์">
                        <a href="<?= base_url('panel/administrator/'.$_SESSION['username'].'/'.'server') ?>" class="btn btn-danger">ย้อนกลับ</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
