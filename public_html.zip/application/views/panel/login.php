﻿<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	


	
<div id="page-wrapper">
     
        
    <center>
        <br><br>
     <div class="site-branding sfc-logo">
         <?php foreach ($this->user_model->view_asset() as $row): ?>
			 <div class="beta site-title"><a href="/" ><img src="<?= $row['png']?>" width="100" height="100" alt="logo.ico" /></a>
</div>		
			<?php endforeach; ?> 
		
	


	

	
                            
						<div class="col-md-4 col-md-offset-4">                            
                <?php if (validation_errors()) : ?>
                    <?= validation_errors() ?>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
                   
                    <div class="btn btn-danger" role="alert"><?= $error ?></div><?php endif; ?>
					
					</div> </div>
				
				

	
<section id="#login">
	   <div class="container">
                            <div class="col-md-4 col-md-offset-4">                            
                                
                                   </div></div>
                                   
                               <?= form_open() ?>
                                   <div class="col-md-4 col-md-offset-4">                            
                            <fieldset>
                                <div class="form-group">
     <p for="username"><center>ชื่อผู้ใช้<center></p>
                                        <input class="text-center form-control" placeholder="อย่างน้อง 4 ตัว ภาษา en เท่านั้น" name="username" type="text" autofocus required>
                                    </div>
                                    
                                <div class="form-group">
                                         <p for="password"><center>รหัสผ่าน<center></p>
                                        <input  class="text-center form-control" placeholder="อย่างน้อง 4 ตัว ภาษา en เท่านั้น" name="password" type="password" required>
                                    </div>
                                
                                <input type="submit" class="btn btn-primary form-control" value="เข้าสู่ระบบ"></input><br><br>
                          
                             <div align="center">สมัคสมาชิกใหม่<a href="/panel/register"> คลิกที่นี่...</a></div>
                            </fieldset>
                        </form>
                    
                    
                
		
        <!-- Warper Ends Here (working area) -->


                    <br>  
                      
                    
		  

	
     
<?php foreach ($this->user_model->view_asset() as $row): ?>
	
                <div align="center">© FB Groups <a href="<?= $row['groud']?>">กลุ่มเฟสบุค </a></div>
               
              <center>
					Design BY <a target="_blank" href="https://facebook.com/kariya00/" rel="author">Sakariya Misayalong   </a>	
	</center>

<?php endforeach; ?> 
                </div>
           
          </div>
        </div>
  
     </section>
     </div>
  
    </div>
</center>
</body>
</html>
