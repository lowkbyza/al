<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
	


	

	<div id="page-wrapper">
    <center>
     <br><br>
     <div class="site-branding sfc-logo">
			<?php foreach ($this->user_model->view_asset() as $row): ?>
			 
			<div class="beta site-title"><a href="/" target="_top"><img src="<?= $row['png']?>" width="100" height="100" alt="logo.ico" /></a></div>		
			<?php endforeach; ?> 
		
	


	

	
                            
						<div class="col-md-4 col-md-offset-4">                            
                <?php if (validation_errors()) : ?>
                    <button class="btn btn-danger"><?= validation_errors() ?>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
					</button>
					</div>
				
				

<section id="#login">
	   <div class="container">
                            <div class="col-md-4 col-md-offset-4">                            
                                <div class="btn btn-danger" role="alert"><?= $error ?></div><?php endif; ?>
                                   </div></div>
                                   
                               <?= form_open() ?>
                   <div class="col-md-4 col-md-offset-4">                            
                            <fieldset>
                                <div class="form-group">
     <p for="username"><center>ชื่อผู้ใช้<center></p>
                                        <input class="text-center form-control" placeholder="อย่างน้อง 4 ตัว ภาษา en เท่านั้น" name="username" type="text" autofocus required>
                                    </div>
                               
                                <div class="form-group">
                                         <p for="password"><center>รหัสผ่าน<center></p>
                                        <input class="text-center form-control" placeholder="อย่างน้อง 4 ตัว ภาษา en เท่านั้น" name="password" type="text-center" required>
                                    </div>
                               
                                
                                <div class="form-group">
                                    <p for="password_confirm"><center>ยืนยันรหัสผ่าน<center></p>
                                        <input class="text-center form-control" placeholder="ใส่หรัสให้ตรงกันกับช่องบน" name="password_confirm" type="text-center" required>
                                    </div>
                                   
          <input name="email" type="hidden" value="smilevpn@gmail.com" id="email">
                                
                                <input type="submit" class="btn btn-primary form-control" value="ยืนยันสมัคสมาชิก"></input><br><br>
                          
                             
                            </fieldset>
                        </form>
                    
                    </section>
                 
		 <br>
        <!-- Warper Ends Here (working area) -->


                    
		  

	
     

	
                

</center>
                
  
          
        </div>
  </div>
    </div>
     

</body>
</html>
