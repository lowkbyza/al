<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div id="page-wrapper">
<div class="row"> 
    <div class="col-lg-12"> 
          
      <h3>
       วิธีเติมเครดิต AutoWallet
      </h3>
    <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-th-list fa-fw"></i> หน้าหลัก</a></li>
		<li class="active">วิธีเติมเครดิต</li>
		</ol>
<div class="panel-body">
	
			  
     <center> 
           <?php foreach ($this->user_model->view_wallet() as $row): ?>
					<?php if (!empty($row['phone'])): ?>
           </div>
           <center>
<?php if (isset($message)) {echo $message; }?>
	<ol class="breadcrumb"><br>
<FONT COLOR='#FF0800' size='5'>เพียงทำตามขันตอน</FONT>
<br><br>
โอนทรูวอเล็ทเข้าบัญชี <?= $row['phone']?><br>
และนำเลขที่อ้างอิงที่ได้มาเพื่อยืนยันรับเครดิต
<form method="post" action="/wallet/check.php">
<?php foreach ($this->user_model->view_token() as $row): ?>
                    <input name="noty_wallet" type="hidden" value="<?= $row['wallet']; ?>" id="noty_wallet">
                        <?php endforeach; ?>
                <?php foreach ($this->user_model->view_wallet() as $row): ?>
                    <input name="phone" type="hidden" value="<?= $row['phone']; ?>" id="phone">
                        
                        <input name="passwd" type="hidden" value="<?= $row['passwd']; ?>" id="passwd">
                            <input name="email" type="hidden" value="<?= $row['email']; ?>" id="email">
                    <?php endforeach; ?>
                                      <?php foreach ($this->user_model->view_asset() as $row): ?>
                                         
                                       <input name="link" type="hidden" value="<?= $row['link']; ?>" id="link">
                                           <input name="web" type="hidden" value="<?= $row['web']; ?>" id="web">
                                               <input name="png" type="hidden" value="<?= $row['png']; ?>" id="png">
                                           <?php endforeach; ?>
                                               <input name="user" type="hidden" value="<?= $_SESSION['username'] ?>" id="user">
                     <center>    <h4><input class="btn btn-warning" type="submit"  value="ยืนยันเลขที่อ้างอิงเพื่อเติมเครดิต " /></h4></center>
                                      
<img src="/wallet/wallet.jpg" width="320" height="360" ></a>
  
                            
                                </form> 
<p>&nbsp;</p> 
<?php endif; ?>	
			   <?php endforeach; ?> 

<font color="#FF4300">
โปรดทราบ.. </font>
<font color="#666666">ถ้าหากเติมไม่ผ่านโปรดติดต่อแอดมินโดยเร็วที่สุด
</font><br><br>

</ol><br><br>
                                        


     
 
                <div align="center">© FB Groups <a href="<?= $row['groud']?>">เข้าร่วมกลุ่มเฟสบุค</a></div>
               
              <center>
					<a href="<?= $row['link']?>">ติดต่อแอดมินคลิกที่นี่...</a>
	</center>

 <p>&nbsp;</p>
</div>

