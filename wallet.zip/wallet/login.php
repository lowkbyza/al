<html>
<head>
<title>MMT-VPN.TK</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-4 col-md-offset-4 ver-center">
<form action="check.php" method="post">
	<div class="form-group">
		<h2>ชื่อผู้ใช้งาน(Username)</h2>
		<input type="text" class="form-control" name="user">
	</div>
         <button class="btn btn-block btn btn-warning" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> เข้าสู่ระบบ</button>
		<a href="http://mmt-server.tk/MMT-VPN/" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                   ย้อนกลับ</a>
	</div>
</form>
</div> 
<p>truemoney wallet auto เพียงแค่นำหมายเลขอ้างอิงมาใส่</p>
<p>เบอร์ wallet:0946255482 (สุทิศา คงคิรินทร์)</p>
<p>กฎการเติมเงิน ห้ามเติมต่ำกว่า10 บาทไม่งั้นระบบจะไม่นำเครดิตเข้าให้</p>
<p>ราคาที่เติม 10 =10 เครดิต</p>
<p>ราคาที่เติม 20 =20 เครดิต</p>
<p>ราคาที่เติม 30 =30 เครดิต</p>
<p>ราคาที่เติม 40 =40 เครดิต</p>
<p>ราคาที่เติม 50 =50 เครดิต</p>
<p>&nbsp;</p>
</div>
<body>
</html>