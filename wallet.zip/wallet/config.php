<?php
$host = 'localhost';
$user = 'id7135887_2855';
$pass = '031329604';//ใส่รหัสครับ phpmyadmin
$db = 'id7135887_285';
$con = mysqli_connect($host,$user,$pass,$db);
mysqli_set_charset($con,'utf8');
?>