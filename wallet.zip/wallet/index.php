<html>
<head>
<title>MMT-VPN.TK</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/spacelab/bootstrap.min.css">
</head>
<body>
<marquee  direction="lefe" scrollamount="13" width="100%">
<h1><font color="#FF00FF">MMT-VPN เน็ตแรง เน็ตเร็ว ปลิงน้อย ต้อง MMT-VPN ที่นี้ที่เดียว ใช้งานกันแบบเต็มที่ ไม่ต้องกลัวหมด</font></h1>
</marquee>
</div>
     <div class="container">
     <div class="row ver-parent">
     <div class="col-md-7 col-md-offset-2 ver-center">
<form action="check.php" method="post">
	<div class="form-group">
  <br />
  <br /> 
    <center><h1><font color="#6600CC">กรุณาใส่ </font><font color="#FF3366">Username</font>
	<font color="#6600CC"> เพื่อเข้าสู่การเติมเงิน</font></h1> </center>
  <br /> 
		<input type="text" class="form-control" name="user" placeholder="กรุณาใส่ Usernameของท่าน ตัวอย่าง เช่น ( Ilikecat123 ) ">
	</div>
         <button class="btn btn-block btn btn-warning" type="submit" name="submit">
		 <i class="fa fa-ravelry" aria-hidden="true">
		 </i> เข้าสู่ระบบเติมเงิน</button>
		<a href="http://mmt-server.tk/MMT-VPN/" class="btn btn-block btn btn-success"><i class="fa fa-ravelry"></i>
                   ย้อนกลับไปหน้าแรก</a>
  <br /> 
  <br /> 
  <br /> 
    <br /> 
	  <br /> 
		<img src = "http://127.0.0.1/img/7c33540d.gif" width="650" height="320" border="1">
	</div>
</form>
</div> 
    <style type="text/css">
<!--
body {

	background-image: url(http://127.0.0.1/img/53999_prison_school.jpg);
	background-attachment: fixed;
	background-position: center top;
	margin: 0px;
	padding: 0px;
}
-->
</style>
</div>
<body>

</html>